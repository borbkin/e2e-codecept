Feature('Login page');

Scenario('Открытие страницы логина', async ({ I }) => {
  I.amOnPage('/login');
  I.wait(1000);
  I.see('Login to your account123');
});